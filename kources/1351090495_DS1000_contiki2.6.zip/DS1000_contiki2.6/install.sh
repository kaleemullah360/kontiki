#!/bin/sh

echo Copying files
cp -i DS1000.c ~/contiki/platform/sky/dev/
cp -i DS1000.h ~/contiki/platform/sky/dev/
echo "CONTIKI_TARGET_SOURCEFILES += DS1000.c" >> ~/contiki/platform/sky/Makefile.sky
echo Done
